from setuptools import setup
setup(name='576_project', version = '1', packages = ['mf_pkg'])
