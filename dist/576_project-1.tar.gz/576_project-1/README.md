# 576_project
Variant caller and browser interface.

a variant caller which identifies variants in a DNA, RNA, or protein sequence, as compared to a reference. After identifying the variants, it highlights all of the variants on the USGS Genome browser, and provides a searchable list of all of the variants
