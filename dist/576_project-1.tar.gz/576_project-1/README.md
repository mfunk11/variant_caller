# Variant caller Graphical Interface


Package to align and visualize variants in genomes. Inputs NGS data plus a reference file, and uses STAR and GATK to align reads and detect variant. Views variant on a Genome Browser. 



